package com.io.interview_practice;

public class StringExample {
    public static void main(String[] args) {


        String str1 = "hello";
        String str2 = "hello";

        System.out.println(str1 == str2);
    }


}
