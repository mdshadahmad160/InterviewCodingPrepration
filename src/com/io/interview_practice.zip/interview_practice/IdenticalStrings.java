package com.io.interview_practice;

public class IdenticalStrings {
    public static void main(String[] args) {
        String str1 = "hello";
        String str2 = "hello";
        boolean result = str1.equals(str2);
        System.out.println("Are Strings Identical ?" + result);
    }
}
